# 部分弹幕功能代码来自项目：https://github.com/IsoaSFlus/danmaku，感谢大佬
# 快手弹幕代码来源及思路：https://github.com/py-wuhao/ks_barrage，感谢大佬
# 仅抓取用户弹幕，不包括入场提醒、礼物赠送等。


import asyncio
import danmaku
import time
import csv
import pandas as pd
import datetime
import argparse


async def printer(q):
    while True:
        m = await q.get()
        if m['msg_type'] == 'danmaku':
            csv_writer.writerow([time.time(), m["name"], m["content"]])
            # print(f'{m["name"]}：{m["content"]}')


async def main(url):
    q = asyncio.Queue()
    dmc = danmaku.DanmakuClient(url, q)
    asyncio.create_task(printer(q))
    await dmc.start()


def parse_args():
    parser = argparse.ArgumentParser('Argument for LPL Spider')

    parser.add_argument('--add', type=str, default='https://www.huya.com/lpl',
                        help='The Live Stream Address')
    parser.add_argument('--month', type=int, default=0, help='start month')
    parser.add_argument('--day', type=int, default=0, help='start day')
    parser.add_argument('--hour', type=int, default=0, help='start hour')
    parser.add_argument('--minute', type=int, default=0, help='start minute')
    args = parser.parse_args()

    return args


args = parse_args()
add = args.add

# Compute the waiting time before executing crawling
# If intent to execute this immediately, set month to 0
if args.month == 0:
    time_wait = 0
else:
    time_now = time.time()
    start_time_string = "2023-%d-%d %d:%d:00" % (args.month, args.day, args.hour, args.minute)
    print(start_time_string)
    start_time = time.mktime(time.strptime(start_time_string, "%Y-%m-%d %H:%M:%S"))
    time_wait = start_time - time_now
print(time_wait)
time.sleep(time_wait)

plats = ["bilibili", "huya"]
for plat in plats:
    if plat in add:
        selected_plat = plat
date = datetime.datetime.now()
path = 'Platform_' + selected_plat + '_' + str(date.year) + '_' + str(date.month) + '_' + str(date.day) + '_' + str(date.hour) + '_' + str(date.minute) + '_TS_' + str(round(time.time())) + '.csv'
file = open('../Data/' + path, 'a+', encoding='utf-8', newline='')
csv_writer = csv.writer(file)
csv_writer.writerow(['Timestamp', 'User', 'Message'])
bullets = pd.DataFrame(columns=['Timestamp', 'User', 'Message'])
asyncio.run(main(add))
asyncio.run(main(add))


'''Two Examples for LPL'''

# python main.py --add https://www.huya.com/lpl --month 01 --day 11 --hour 17 --minute 20
# python main.py --add https://live.bilibili.com/6 --month 01 --day 11 --hour 17 --minute 20
## To execute the program
```js
 cd danmu
 python main.py --add https://www.huya.com/lpl --month 01 --day 14 --hour 07 --minute 20
 python main.py --add https://live.bilibili.com/6 --month 01 --day 14 --hour 07 --minute 20
```

## Suggestions
- For each live platform, we should run a program.
- Run this program day(s) before each gaming day, and set the start time to several mins/hours before the first BO3/BO5 game will start.
- Interrupt this program several mins/hours after the last BO3/BO5 game of the current gaming day ends, then run a new one for the next gaming day.
- On each gaming day, we intend to collect 2 cvs files corresponding to two live platforms.
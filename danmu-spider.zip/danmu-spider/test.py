import csv
import time

plat = "Bilibili"
path = 'Platform_' + plat + '_TS_' + str(round(time.time())) + '.csv'
file = open('Data/' + path, 'a+', encoding='utf-8', newline='')
csv_writer = csv.writer(file)